export interface CategoriaUtente {
    id:number;
    nomeCat:string;
    descrCat: string;
    photo: string;
    linkCat:string;
   
}
